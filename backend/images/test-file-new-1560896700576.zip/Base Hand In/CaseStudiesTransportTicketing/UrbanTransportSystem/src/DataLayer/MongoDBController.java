/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataLayer;

import java.util.List;
import org.bson.Document;
import DataTypes.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import urbantransportsystem.GateController;
/**
 *
 * @author Bomie
 */
public class MongoDBController {

    private static Account tempAccount;
    private static Token tempToken;
    
    static List<Document> fetch(String dataProject, String staffAccounts) {
        return null;
    }
    
    /**
     * This method populates the StaffAcount list
     * @return tempList List of staffAccounts
     */
    public static List<StaffAccount> getStaffAccounts(){
        List<StaffAccount> tempList =  new ArrayList<>();
        tempList.add(new StaffAccount("admin", "pass"));
        tempList.add(new StaffAccount("testStaff", "pass2"));
        return tempList;
    }
    
    /**
     * This method populates the Account list
     * @return tempList List of Accounts
     */
    public static List<Account> getAccounts(){
        List<Account> tempList = new ArrayList<>();
        tempAccount = new Account("TestUser", "pass", "Normal", 10.00f, "name");
        tempList.add(tempAccount);
        tempList.add(new Account("TestUser2", "pass2", "Anonymous", 0.00f, "name"));
        return tempList;
    }
    
    /**
     * This method populates the Tokens list
     * @return tempList List of Tokens
     */
    public static List<Token> getTokens(){
        List<Token> tempList = new ArrayList<>();
        getTicketTypes();
        tempToken = new Token( new NormalAccount(tempAccount, LocalDate.now()), SetOfTicketTypes.setOfTicketTypes.get(0));
        tempList.add(tempToken);
        return tempList;
    }
    
    public static void getTransactions(){
        new Transaction(PaymentTypes.CASH,10.00f );
    }
    
    /**
     * This method populates the getJourneys list
     * @return tempList List of Journeys
     */
    public static List<Journey> getJourneys(){
        List<Journey> tempList = new ArrayList<>();
        List<String> tempLocationsList = new ArrayList<>();
        tempLocationsList.add("London");
        tempLocationsList.add("Birmingham");            
        tempList.add(new Journey(tempToken, "London", "Birmingham", new Date(1980, 1, 2), new Date(2015, 3,22), 10.00f, new FareRules(tempLocationsList , 10.00f, 0, 0)));
        return tempList;
    }
    
    /**
     * This method populates the Sensors list
     * @return tempList List of Sensors
     */
    public static List<Sensor> getSensors(){
        List<Sensor> tempList = new ArrayList<>();
        tempList.add(new Sensor("Birmingham New Street", new GateController()));
        tempList.add(new Sensor("Birmingham", new GateController()));
        tempList.add(new Sensor("Sheffield", new GateController()));
        tempList.add(new Sensor("Penkridge", new GateController()));
        tempList.add(new Sensor("Huddersfield", new GateController()));
        tempList.add(new Sensor("London", new GateController()));
        return tempList;
    }

    /**
     * This method populates the SmartCards list
     * @return tempList List of SmartCards
     */
    public static List<SmartCard> getSmartCards() {
        List<SmartCard> tempList = new ArrayList<>();
        tempList.add(new SmartCard(111111, "TestUser"));
        tempList.add(new SmartCard(111112, "TestUser2"));
        return tempList;
    }
    
    /**
     * This method populates the Routes list
     * @return tempList List of routes
     */
    public static List<Routes> getRoutes(){
        List<Routes> tempRoutes = new ArrayList<>();
        String[]stops = {"Birmingham", "London"};
        LocalTime[] localTime = {LocalTime.of(7, 0),LocalTime.of(12,0), LocalTime.of(15,0), LocalTime.of(19,0) };
        tempRoutes.add(new Routes(Arrays.asList(stops), Arrays.asList(localTime), 5.00f));
        stops = new String[]{"Sheffield","Penkridge", "Birmingham New Street"};
        localTime = new LocalTime[]{LocalTime.of(7, 30),LocalTime.of(12,30), LocalTime.of(15,30), LocalTime.of(19,30) };
        tempRoutes.add(new Routes(Arrays.asList(stops), Arrays.asList(localTime), 2.50f));
        stops = new String[]{"Birmingham New Street", "Huddersfield"};
        localTime = new LocalTime[]{LocalTime.of(7, 0),LocalTime.of(12,0), LocalTime.of(15,0), LocalTime.of(19,0) };
        tempRoutes.add(new Routes(Arrays.asList(stops), Arrays.asList(localTime),10.00f));
        return tempRoutes;
    }

    /**
     * This method populates the Discounts list
     * @return tempList List of discounts
     */
    public static List<Discount> getDiscounts() {
        List<Discount> tempList = new ArrayList<>();
        tempList.add(new Discount("Student Card", 0.8f));
        tempList.add(new Discount("OAP Discount", 0.7f));
        return tempList;
    }

    /**
     * This method populates the Token/Ticket Type list
     * @return tempList List of Token/ticket types
     */
    static void getTicketTypes() {
        List<TicketTypes> tempList = new ArrayList<>();
        tempList.add(new TicketTypes("Normal" , 1f));
        tempList.add(new TicketTypes("Family", 2.5f));
        tempList.add(new TicketTypes("Season", false, 90f));
        tempList.add(new TicketTypes("SmartCard", 1f));
        tempList.add(new TicketTypes("DayPass", false, 30f));
        SetOfTicketTypes.setOfTicketTypes =  tempList;
    }
}
