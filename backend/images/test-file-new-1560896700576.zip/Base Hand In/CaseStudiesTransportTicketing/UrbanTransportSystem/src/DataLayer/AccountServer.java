/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataLayer;

import DataTypes.Account;
import DataTypes.SetOfAccounts;
import urbantransportsystem.StartUI;

/**
 *
 * @author Charlie
 */
public class AccountServer {
    
    /**
     * This method processes the login for a user
     * @param username The username logged in with
     * @param password The password logged in with
     * @return SetOfAccounts Finds the user that attempted to log in
     */
    public static Account processLogin(String username, String password) {
        return SetOfAccounts.findAccount(username, password);
        //validateLogin(SetOfAccounts.findAccount(username, password));
    }
    
    /**
     * This method validates the log in attempt
     * @param tempAccount The account that attempted to log in
     */
    public void validateLogin(Account tempAccount){
        if(tempAccount == null) {
            showInvalidLogin();
        } else {
            new StartUI().setVisible(true);
        }
    }
    
    private void showInvalidLogin(){
        
    }
}
