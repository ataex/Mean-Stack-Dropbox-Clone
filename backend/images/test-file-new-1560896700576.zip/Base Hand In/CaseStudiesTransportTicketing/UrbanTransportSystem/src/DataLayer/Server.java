/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataLayer;

import DataTypes.*;
import urbantransportsystem.DEVControlUpdater;



/**
 *
 * @author Bomie
 */
public class Server {
    /**
     * This constructor method initialises the base Server class and enables the system to be usable from start up
     */
    public Server(){
        SetOfStaffAccounts.listOfStaffAccounts = MongoDBController.getStaffAccounts();
        SetOfAccounts.setOfAccounts = MongoDBController.getAccounts();
        SetOfTokens.listOfTokens = MongoDBController.getTokens();
        MongoDBController.getTransactions();
        SetOfJourneys.journey = MongoDBController.getJourneys();
        SetOfSensors.listOfSensors = MongoDBController.getSensors();
        SetOfSmartCard.listOfSmartCards = MongoDBController.getSmartCards();
        SetOfRoutes.routes = MongoDBController.getRoutes();
        SetOfDiscounts.discountTypes = MongoDBController.getDiscounts();
        urbantransportsystem.DEVControl local = new urbantransportsystem.DEVControl();
        new Thread(new DEVControlUpdater(local)).start();
    }
    
    public Integer processFareHistory(Integer id) {
        return null;
    }
    
    public void processFareList(){
        
    }
    
    public void processJourneys(String from, String to) {
        
    }
    
    public void showDelays(){
        
    }
}
