/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package urbantransportsystem;

import DataLayer.Server;
import DataTypes.Account;
import java.math.BigDecimal;
import java.math.RoundingMode;
import javax.swing.JOptionPane;

/**
 *
 * @author Bomie
 */
public class StartUI extends javax.swing.JFrame {

    
    private float creditAmount;
    
    /**
     * This method gets the value of the top up text box.
     * @return The actual value to top up
     */
    private String getActualTopUpText(){
        return TopUpVal.getText().replace("£", "");
    }
    
    /**
     * This method tops up the account with the topUpAmount
     * @param topUpAmount The amount to top up
     */
    public void topUp(float topUpAmount){
        creditAmount += topUpAmount;
    }
    
    public void displayFareHistory(){
        
    }
    
    public void showCurrentAccount(){
        
    }
    
    /**
     * This method creates a new form NormalUI
     */
    public StartUI() {
        initComponents();
        
        Server server = new Server();
        showOptions();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jFrame1 = new javax.swing.JFrame();
        jFrame2 = new javax.swing.JFrame();
        jFrame3 = new javax.swing.JFrame();
        jLabel1 = new javax.swing.JLabel();
        TopUpVal = new javax.swing.JTextField();
        TopUpBtn = new javax.swing.JButton();
        WarningOnInvalidNumberLbl = new javax.swing.JLabel();
        CreditAmount = new javax.swing.JLabel();
        btnAccessPayMachine = new javax.swing.JButton();
        btnShowMobileUI = new javax.swing.JButton();
        btnNormalAdmin = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame2Layout = new javax.swing.GroupLayout(jFrame2.getContentPane());
        jFrame2.getContentPane().setLayout(jFrame2Layout);
        jFrame2Layout.setHorizontalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame2Layout.setVerticalGroup(
            jFrame2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jFrame3Layout = new javax.swing.GroupLayout(jFrame3.getContentPane());
        jFrame3.getContentPane().setLayout(jFrame3Layout);
        jFrame3Layout.setHorizontalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame3Layout.setVerticalGroup(
            jFrame3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("TopUpAmount");

        TopUpVal.setText("£0.00");
        TopUpVal.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TopUpValMouseClicked(evt);
            }
        });
        TopUpVal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                TopUpValKeyReleased(evt);
            }
        });

        TopUpBtn.setText("TopUp");
        TopUpBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TopUpBtnActionPerformed(evt);
            }
        });

        WarningOnInvalidNumberLbl.setForeground(new java.awt.Color(204, 0, 51));

        CreditAmount.setText("Credit Amount : ");

        btnAccessPayMachine.setText("Show Pay Machine UI");
        btnAccessPayMachine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAccessPayMachineActionPerformed(evt);
            }
        });

        btnShowMobileUI.setText("Show Mobile UI");
        btnShowMobileUI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowMobileUIActionPerformed(evt);
            }
        });

        btnNormalAdmin.setText("ADMIN");
        btnNormalAdmin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNormalAdminActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(CreditAmount)
                            .addComponent(WarningOnInvalidNumberLbl)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(TopUpVal, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(39, 39, 39)
                                .addComponent(TopUpBtn))))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(btnAccessPayMachine, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnShowMobileUI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnNormalAdmin, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(290, 290, 290)))
                .addContainerGap(45, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(WarningOnInvalidNumberLbl)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(TopUpVal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(TopUpBtn))
                .addGap(18, 18, 18)
                .addComponent(CreditAmount)
                .addGap(52, 52, 52)
                .addComponent(btnAccessPayMachine)
                .addGap(18, 18, 18)
                .addComponent(btnShowMobileUI)
                .addGap(18, 18, 18)
                .addComponent(btnNormalAdmin)
                .addContainerGap(84, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    private String username;
    private Account localAccount;
    
    /**
     * On the mouse clicking the text field we want to clear it
     * @param evt The mouse click event
     */
    private void TopUpValMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TopUpValMouseClicked
        TopUpVal.setText("£");
    }//GEN-LAST:event_TopUpValMouseClicked

    /**
     * On release we want to check to see if they used only numbers
     * @param evt The key release event
     */
    private void TopUpValKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_TopUpValKeyReleased
        System.out.println("Called");
        if (!getActualTopUpText().matches("^[1-9]\\d*(\\.\\d+)?$")){//If it's not numerical or a  . with numbers behind it
            WarningOnInvalidNumberLbl.setText("The number is invalid");
        }else {
            WarningOnInvalidNumberLbl.setText("");
        }
    }//GEN-LAST:event_TopUpValKeyReleased
    public void showOptions(){
        
    }
    /**
     * Attempts to submit the topUpVal to the server
     * @param evt The mouse click event
     */
    private void TopUpBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TopUpBtnActionPerformed
        if (!getActualTopUpText().matches("^[1-9]\\d*(\\.\\d+)?$")||
                tryParseDouble(getActualTopUpText()) < 0){//If it's not numerical or a  . with numbers behind it or if it's not greater than 0
            JOptionPane.showConfirmDialog(rootPane, "The topup amount is not valid and therefore cannot be submmitted");
            return;
        }
        double amount = round(tryParseDouble(getActualTopUpText()), 2); 
        localAccount.updateBalance(amount);
        CreditAmount.setText("Credit Amount : £"+ localAccount.getBalance());
    }//GEN-LAST:event_TopUpBtnActionPerformed

    private void btnAccessPayMachineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAccessPayMachineActionPerformed
       // this.setVisible(false);
        PayMachine payMachine = new PayMachine();
        
        payMachine.setVisible(true);
       // this.dispose();

    }//GEN-LAST:event_btnAccessPayMachineActionPerformed

    private void btnShowMobileUIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowMobileUIActionPerformed
        NormalUI mobileApp = new NormalUI();
        mobileApp.setVisible(true);
    }//GEN-LAST:event_btnShowMobileUIActionPerformed

    private void btnNormalAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNormalAdminActionPerformed
        LoginUI adminControl = new LoginUI();
        adminControl.staff = true;
        adminControl.setVisible(true);
        //StaffUI adminControl = new StaffUI();
        //adminControl.setVisible(true);
    }//GEN-LAST:event_btnNormalAdminActionPerformed
     
    /**
    * This method attempts to parse a double then returns it
    * @param val The string passed in
    * @return String as double, -1 if exception occurs
    */
     private double tryParseDouble(String val){
        double d;
        try {
            d = Double.parseDouble(val);
        }
        catch (NumberFormatException e) {
            // Use whatever default you like
            d = -1.0;
        }
        return d;
     }    

    /**
    * This method rounds to the specified number of decimal places
    * @param value The value to round
    * @param places The places you want
    * @return Rounded val
    */
    public static double round(double value, int places) {
        if (places < 0) throw new IllegalArgumentException();

        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }
    
    /** Main method
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StartUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StartUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StartUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StartUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StartUI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel CreditAmount;
    private javax.swing.JButton TopUpBtn;
    private javax.swing.JTextField TopUpVal;
    private javax.swing.JLabel WarningOnInvalidNumberLbl;
    private javax.swing.JButton btnAccessPayMachine;
    private javax.swing.JButton btnNormalAdmin;
    private javax.swing.JButton btnShowMobileUI;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JFrame jFrame2;
    private javax.swing.JFrame jFrame3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
