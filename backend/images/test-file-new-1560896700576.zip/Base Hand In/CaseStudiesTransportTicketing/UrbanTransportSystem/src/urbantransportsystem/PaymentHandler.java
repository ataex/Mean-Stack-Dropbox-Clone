/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package urbantransportsystem;

/**
 *
 * @author Charlie
 */
public class PaymentHandler {
    /**
     * This method would authorise the payment attempt
     * @param amount The amount to pay
     * @param methodOfTopup The method of payment
     * @param externalDetails The external payment provider details
     */
    public void authorise(Float amount, String methodOfTopup, String externalDetails){
        //TODO: goes to external process payment which just does nothing.
    }
}
