/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author Bomie
 */
public class Transaction {
    
    private Integer transactionId;
    private Enum transactionType;
    private Float transactionAmount;
    
    
    /**
     * This method processes a transaction and adds it to transactionList
     * @param methodOfTopup The method of top up
     * @param amount The amount to top up
     */
    public Transaction(Enum methodOfTopup, float amount){
        int temp;
        
        if (!SetOfTransactions.transactionList.isEmpty())
            temp = SetOfTransactions.transactionList.get(SetOfTransactions.transactionList.size() -1).transactionId;
        else 
            temp = -1;
        transactionId = temp +1;
        this.transactionType = methodOfTopup;
        this.transactionAmount = amount;
        SetOfTransactions.transactionList.add(this);
    }
}
