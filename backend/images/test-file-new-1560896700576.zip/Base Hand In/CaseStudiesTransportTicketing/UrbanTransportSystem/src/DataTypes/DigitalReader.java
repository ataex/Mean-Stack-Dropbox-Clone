/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.Date;
import java.util.List;

/**
 *
 * @author Bomie
 */
public class DigitalReader {

    public static int fakeTokenIdentifier;

    private int digitalReaderId;

    /**
     * This method retrieves the readerType
     * @return readerType The type of reader
     */
    public String getReaderType() {
        return readerType;
    }

    /**
     * This method retrieves the currentTime
     * @return currentTime The current time
     */
    public Date getCurrentTime() {
        return currentTime;
    }
    
    private String readerType;
    private Date currentTime;
    private Location currentLocation;

    /**
     * This method reads the token at station entry
     * @param id The id of the token it's receiving from the gate controller
     * @param location The physical station location of the gate controller
     */
    public void readTokenAtEntry(int id, String location) {
        Token t = SetOfTokens.findToken(id);
        if (t != null) {
            if (t.getTokenType().equals("NormalAccount")) {
                t.getAccount();
                FareRules rules = t.getListOfJourneys().get(0).getFareRules();
                float temp = rules.getMinAmount();
                if (t.hasSufficentCredit()) {
                    entryPermitted();
                    createJourney(t, location);
                    return;
                }
            }
        }
        denyEntry();
    }

    /**
     * This method reads the token at station exit
     * @param id The id of the token it's receiving from the gate controller
     * @param location The physical station location of the gate controller
     */
    public void readTokenAtExit(int id, String location) {
        Token t = SetOfTokens.findToken(id);
        if (t != null) {
            if (t.hasSufficentCredit()) {
                entryPermitted();
                createJourney(t, location);
                return;
            }
        }
        denyEntry();
    }

    /**
     * This method is supposed to play some audio whether entry is permitted or denied
     */
    public void playAudio() {
    }

    /**
     * This method is supposed to play some audio if entry is permitted and move the barrier
     */
    public void entryPermitted() {
        playAudio();
    }

    /**
     * This method is supposed to play some audio if entry is denied and not move the barrier
     */
    public void denyEntry() {
        playAudio();
    }

    /**
     * This method creates the journey that the user has undertaken
     * @param t A token instance
     * @param location The physical station location of the gate controller the user is currently at
     */
    public void createJourney(Token t, String location) {
        if (t.getListOfJourneys().get(t.getListOfJourneys().size()).getToLocation() == null) { //if the journey is not complete
            t.getListOfJourneys().get(t.getListOfJourneys().size()).setToLocation(location);
            //t.getListOfJourneys().get(t.getListOfJourneys().size()).setAmountPaid(t.getListOfJourneys().get(t.getListOfJourneys().size()).get);
        } else { //if this is the start of a new journey
            List<Journey> tempList = t.getListOfJourneys();
            //tempList.add(new Journey(t, location,null, new Date() , null, 0f, new FareRules(locations, digitalReaderId, digitalReaderId, digitalReaderId) ));
            t.setListOfJourneys(tempList);
        }
    }
}
