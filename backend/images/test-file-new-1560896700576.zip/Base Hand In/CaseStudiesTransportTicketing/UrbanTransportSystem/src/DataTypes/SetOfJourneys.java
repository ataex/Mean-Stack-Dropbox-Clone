/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bomie
 */
public class SetOfJourneys {
    public static List<Journey> journey = new ArrayList<Journey>();
    
    /**
     * This method gets the amount for all journeys travelled by a user
     * @param id The user/token ID
     * @return  value The cost of all journeys
     */
    public static float getAmountForAllJourneys(String id){
        int value = 0;
        for (Journey tempJourney: journey){
            if (tempJourney.getTokenUsed().TokenUser.getType().equals("NormalAccount")){
                NormalAccount localToken = (NormalAccount) tempJourney.getTokenUsed().TokenUser;
                if (localToken.getUsername().getAccountUserName().equals(id)){
                     value += tempJourney.getAmountPaid();
                }
            }
        }
        return value; 
    }
    
    /**
     * This method gets recent journeys made
     * @param id The user/token ID
     * @return tempList The list of recent journeys
     */
    public static List<Journey> getRecentJourneys(String id){
        List<Journey> tempList = new ArrayList<>();
        for (Journey tempJourney: journey){
            if (tempJourney.getTokenUsed().TokenUser.getType().equals("NormalAccount")){
                NormalAccount localToken = (NormalAccount) tempJourney.getTokenUsed().TokenUser;
                if (localToken.getUsername().getAccountUserName().equals(id)){
                    tempList.add(tempJourney);
                }
            }
        }
        return tempList;
    }
    
    /**
     * This method gets info for a specified journey
     * @param tokenId The token ID used for a journey
     * @return  tempJourney The journey associated to a token ID
     * @return null
     */
    public static Journey getSpecifiedJourney(int tokenId){
        for (Journey tempJourney : journey){
            if (tempJourney.getTokenUsed().getTokenID() == tokenId){
                return tempJourney;
            }
        }
        return null;
    }
}
