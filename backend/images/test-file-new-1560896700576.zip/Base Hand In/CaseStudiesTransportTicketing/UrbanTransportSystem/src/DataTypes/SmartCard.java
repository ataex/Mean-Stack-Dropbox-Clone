/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.time.LocalDate;

/**
 *
 * @author Bomie
 */
public class SmartCard {
    private String owner;
    private int pin;//This needs to be 6 digits
    
    /**
     * This method initialises an instance of SmartCard setting pin and owner
     * @param pin   PIN for the SmartCard
     * @param owner Owner of the SmartCard
     */
    public SmartCard(int pin, String owner){
        this.pin = pin;
        this.owner= owner;
    }
    
    /**
     * This method retrieves the Account associated with the SmartCard
     * @return owner Account which owns the SmartCard
     */
    public Account getAccount(){
        for (Account owner : SetOfAccounts.setOfAccounts){
            if (owner.getAccountUserName().equals(this.owner)){
                return owner;
            }
        }
        return null;
    }  
    
    /**
     * This method updates the balance on the SmartCard
     * @param amount The amount to update
     */
    public void updateAccountBalance(float amount){
        for (Account owner : SetOfAccounts.setOfAccounts){
            if (owner.getAccountUserName().equals(this.owner)){
                owner.processTopUp(amount, PaymentTypes.CASH);
            }
        }
    }
    
    /**
     * This method retrieves the pin for the SmartCard
     * @return pin SmartCard pin
     */
    public int getPin (){return pin;}
}
