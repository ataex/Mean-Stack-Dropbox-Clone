/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author BrianSkullMouse
 */
public class Staff {
    private final String StaffName;
    private final String StaffPosition;
    
    /**
     * This method is a constructor to initialise variables for an instance of Staff
     */
    public Staff(){
        StaffName = "Brian";
        StaffPosition = "User";
    }
    
    public void invalidTokenScan(){
        
    }    
}
