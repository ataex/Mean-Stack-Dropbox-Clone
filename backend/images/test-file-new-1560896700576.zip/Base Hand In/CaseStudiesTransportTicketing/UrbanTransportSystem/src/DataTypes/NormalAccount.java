/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.time.LocalDate;
import java.util.Date;

/**
 *
 * @author Bomie
 */
public class NormalAccount extends Passenger{
    /**
     * copied an instance of the class for easier access 
     */
    private Account username;
    private LocalDate dob;
    
    /**
     * This method is a constructor to initialise an instance of NormalAccount
     * @param username Account username
     * @param dob Account date of birth
     */
    public NormalAccount(Account username, LocalDate dob){
        this.username = username;
        this.dob = dob;
        this.type = "NormalAccount";
    }
    
    /**
     * This method retrieves the username of the Account
     * @return username The account username
     */
    public Account getUsername(){
        return username;
    }
}
