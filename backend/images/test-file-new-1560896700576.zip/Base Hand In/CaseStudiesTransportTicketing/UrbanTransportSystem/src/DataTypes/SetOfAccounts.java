/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.List;

/**
 *
 * @author Bomie
 */
public class SetOfAccounts {

    public static List<Account> setOfAccounts;

    /**
     * This method finds the user Account by validating the username and password passed.
     * @param username
     * @param password
     * @return Account if valid else returns null.
     */
    public static Account findAccount(String username, String password) {
        for (Account temp : setOfAccounts) {
            if (username.equals(temp.getAccountUserName()) && password.equals(temp.getAccountPassword())) {
                return temp;
            }
        }
        return null;
    }

    public static Account findAccount(String username) {
        for (Account temp : setOfAccounts) {
            if (username.equals(temp.getAccountUserName()) ) {
                return temp;
            }
        }
        return null;
    }
}
