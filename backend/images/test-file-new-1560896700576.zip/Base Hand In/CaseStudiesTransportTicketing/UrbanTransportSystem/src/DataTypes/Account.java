/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.time.LocalDate;
import java.util.List;


/**
 *
 * @author Bomie
 */
public class Account {
    private final String accountUserName;
    private final String accountPassword; 
    private final String accountType;
    private double creditAmount;
    public String securityAnswer;
    
    /**
     * Constructor to initialise an instance of Account
     * @param name The value you want to pass into accountUserName
     * @param pass The value you want to pass into accountPassword
     * @param type The value you want to pass into accountType
     * @param credit The value you want to pass into creditAmount
     * @param securityAnswer The value you want to pass into securityAnswer
     */
    public Account(String name, String pass, String type, double credit, String securityAnswer){
        accountUserName = name;
        accountPassword = pass;
        accountType = type;
        creditAmount = credit;
        this.securityAnswer = securityAnswer;
        DemoForms.AccountMonitor var = new DemoForms.AccountMonitor();
        var.localAccount = this;
        new Thread(new DemoForms.AccountUpdater(var)).start();
    }

    /**
     * Method to retrieve the accountUserName
     * @return accountUserName
     */
    public String getAccountUserName() {
        return accountUserName;
    }

    /**
     * Method to retrieve the accountPassword
     * @return accountPassword
     */
    public String getAccountPassword() {
        return accountPassword;
    }

    /**
     * Method to retrieve the accountType
     * @return accountType
     */
    public String getAccountType() {
        return accountType;
    }  
    
    /**
     * Method to retrieve the creditAmount on the Account
     * @return creditAmount
     */
    public double getBalance(){
        return creditAmount;
    }
    /**
     * Method to add money to the Account, adds the changeAmount to creditAmount
     * @param changeAmount The value you want to add to creditAmount
     */
    public void updateBalance(double changeAmount){
        creditAmount += changeAmount;
    }
    /**
     * Method to process a top up of an Account
     * @param amount Amount to top up account
     * @param methodOfTopup  Method of top up
     */
    public void processTopUp(float amount , Enum methodOfTopup){
        PaymentHandler.processPayment(amount, methodOfTopup, "what");
        updateBalance(amount);
        
        new Transaction(methodOfTopup, amount);
    }
    /**
     * This should help the user with recovering the account, needs some proper implementation
     */
    public void forgotAccount(){
        //TODO implement
    }

    
    /**
     * Method to check the validity of the entered password
     * @param password  The password entered by the user
     * @return a boolean whether password is valid or not
     */
    public boolean isPasswordValid(String password) {
        if (password.equals(this.accountPassword)){
            return true;
        }
        return false;
    }

    /**
     * Method to check if Account has enough credit to pay for a journey
     * @param journey The 2 locations the Account has travelled between
     */
    public void hasSufficentCredit(List<Journey> journey) {
        
        for (Journey localJourney: journey){
            
            localJourney.getFareRules();
            float min = localJourney.getFareRules().getMinAmount();
        }
    }
    public String from ;
    public String to;
    public LocalDate timeOfLastJourney;
    public float totalVal = 0f;
    
}
