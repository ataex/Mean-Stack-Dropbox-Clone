/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.List;

/**
 *
 * @author Bomie
 */
public class SetOfSensors {
    public static List<Sensor> listOfSensors;
    
    /**
     * This method gets the sensors at a specified location
     * @param location The location to search for sensors
     * @return sensor The sensor in that location
     * @return null
     */
    public static Sensor findSensorAtLocation(String location){
        for (Sensor sensor : listOfSensors){
            if (sensor.location.equals(location)){
                return sensor;
            }
        }
        return null;
    }
}
