/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author Bomie
 */

public class Discount {
    public String discountReason;
    public float discountPercent;
    
    /**
     * 
     * This method is a constructor to initialise an instant of Discount
     * @param discountReason The value you want to pass into discountReason
     * @param discountPercent The value you want to pass into discountPercent
     */
    public Discount(String discountReason, float discountPercent){
        this.discountReason = discountReason;
        this.discountPercent = discountPercent;
    }
}
