/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.List;

/**
 *
 * @author Bomie
 */
public class FareRules {
    private Float minAmount;
    private int dayPassNum;
    /**
     * This will control the list of locations this fare rule covers, any in here will 
     * be considered to be the same price
     */
    private List<String> locations;
    private float farePrice;
    private double discountPercent;
    
    /**
     * Constructor for the FareRules class and initialises the variables
     */
    public FareRules(List<String> locations, float farePrice, double discountPercent, float minAmount){
        this.locations = locations;
        this.farePrice = farePrice;
        this.discountPercent = discountPercent;
        this.minAmount = minAmount;
    }
    
    /**
     * This method calculates the fare for the user to pay
     * @param t Passes the Token/Ticket of the user
     */
    public float calculateFare(Token t){
        float tempPrice = farePrice;
       if (t.isDiscounted()){//if the token is discounted
           tempPrice = calculateDiscount(discountPercent);
       }
       if (tempPrice < minAmount){ //if the price is lower than the minimum amount we can charge
           tempPrice = minAmount;
       }
       return tempPrice;
    }
    
    /**
    * This method calculates the discount to be applied
    * @param n The discount percent
    */
    public float calculateDiscount(double n){
        return (float) (farePrice *n);
    }

    /**
     * This method retrieves the minAmount
     * @return minAmount The minimum amount
     */
    public float getMinAmount(){
        return minAmount;
    }
    
    /**
     * This method returns the fare rules to be applied
     * @return this The current instance of FareRules
     */
    public FareRules getFareRules(){
        return this;
    }

    /**
     * This method returns the number of journeys for a day pass
     * @return dayPassNum The number of journeys for a day pass
     */
    public int getNumForDayPass(){
        return dayPassNum;
    }
}
