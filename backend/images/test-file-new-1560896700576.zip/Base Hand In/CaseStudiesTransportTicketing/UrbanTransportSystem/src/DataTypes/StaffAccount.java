/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author Charlie
 */
public class StaffAccount {
    
    private String username;
    private String password;
    
    /**
     * This method retrieves the staff username
     * @return username Staff username
     */
    public String getUsername(){return username;}
    
    /**
     * This method retrieves the staff password
     * @return password Staff password
     */
    public String getPassword(){return password;}
    
    /**
     * This method sets the staff username and password
     * @param username Staff username passed in
     * @param password Staff password passed in
     */
    public StaffAccount(String username, String password){
        this.username = username;
        this.password = password;
    }
}

