/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bomie
 */
public class Routes {
    public List<String> routes = new ArrayList<>();
    public List<LocalTime> timeOfDepartures = new ArrayList<>();
    public float price;
    
    /**
     * This method is a constructor to initialise an instance of Routes
     * @param routes the values you want to pass into routes
     * @param timeOfDepartures the value you want to pass into timeOfDepartures
     * @param price the value you want to pass into price
     */
    public Routes(List<String> routes, List<LocalTime> timeOfDepartures, float price){
        this.routes = routes;
        this.timeOfDepartures = timeOfDepartures;
        this.price = price;
    }
}
