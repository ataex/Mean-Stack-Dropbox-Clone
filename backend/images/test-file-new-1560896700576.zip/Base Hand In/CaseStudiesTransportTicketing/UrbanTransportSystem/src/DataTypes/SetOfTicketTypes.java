/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.List;

/**
 *
 * @author Bomie
 */
public class SetOfTicketTypes {

    public static List<TicketTypes> setOfTicketTypes;

    /**
     * This method retrieves the list of specified ticket types
     * @param name The name of the ticket type
     * @return  ticket The ticket
     * @return null
     */
    public static TicketTypes getTicketType(String name) {
        for (TicketTypes ticket : setOfTicketTypes) {
            if (ticket.name.equals(name)) {
                return ticket;
            }
        }
        return null;

    }
}
