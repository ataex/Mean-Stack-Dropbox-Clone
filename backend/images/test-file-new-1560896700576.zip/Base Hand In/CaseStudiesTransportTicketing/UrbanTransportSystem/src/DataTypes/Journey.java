/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.Date;

/**
 *
 * @author Bomie
 */
public class Journey {
    /**
     * This method is a constructor to initialise an instance of Journey
     * @param token Token
     * @param fromLocation Starting location
     * @param toLocation Destination location
     * @param startDate Start date
     * @param toDate End date
     * @param AmountPaid Amount paid
     * @param rules Fare rules
     */
    public Journey(Token token, String fromLocation, String toLocation, Date startDate, Date toDate, float AmountPaid, FareRules rules){
        int temp;
        if (!SetOfJourneys.journey.isEmpty())
            temp = SetOfJourneys.journey.get(SetOfJourneys.journey.size()-1).journeyId;
        else 
            temp = -1;
        journeyId = temp +1;
        this.tokenUsed = token;
        this.fromLocation = fromLocation;
        this.toLocation = toLocation;
        this.startDate = startDate;
        this.toDate = toDate;
        this.amountPaid = AmountPaid;
        this.fareRule = rules;
    }
    
    public Boolean used = false;
    private int journeyId;
    private Token tokenUsed;
    private String fromLocation;
    private String toLocation;
    private Date startDate;

    /**
     * This method retrieves tokenUsed
     * @return tokenUsed 
     */
    public Token getTokenUsed() {
        return tokenUsed;
    }

    /**
     * This method retrieves the starting location
     * @return fromLocation The starting location
     */
    public String getFromLocation() {
        return fromLocation;
    }

    /**
     * This method retrieves the final destination
     * @return toLocation The end destination
     */
    public String getToLocation() {
        return toLocation;
    }

    /**
     * This method sets the final destination
     * @param toLocation The end destination
     */
    public void setToLocation(String toLocation) {
        this.toLocation = toLocation;
    }

    /**
     * This method sets the date
     * @param toDate The date
     */
    public void setToDate(Date toDate) {
        this.toDate = toDate;
    }

    /**
     * This method sets the amount to pay
     * @param amountPaid Amount to pay
     */
    public void setAmountPaid(float amountPaid) {
        this.amountPaid = amountPaid;
    }
    
    /**
     * This method retrieves the fareRules
     * @return fareRule The fareRules for the ticket and journey
     */
    public FareRules getFareRules(){return fareRule;}
    
    /**
     * This method to retrieves the amount that has been paid
     * @return amountPaid Amount paid for journey
     */
    public float getAmountPaid(){return amountPaid; }
    
    private Date toDate;
    private float amountPaid;
    private FareRules fareRule;
    
}
