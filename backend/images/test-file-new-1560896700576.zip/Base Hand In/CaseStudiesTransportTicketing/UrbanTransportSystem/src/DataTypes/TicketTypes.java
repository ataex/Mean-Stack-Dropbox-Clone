/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author Bomie
 */
public class TicketTypes {

    /**
     * This method looks for the type of tickets
     * @return type Ticket type
     * @return null
     */
    static TicketTypes find(String normalAccount) {
        for (TicketTypes type : SetOfTicketTypes.setOfTicketTypes){
            if (type.name.equals( normalAccount)){
                return type;
            }
        }
        return null;
    }
    
    public float percentageIncreaseInPrice;
    public float setPrice =  -1;
    public String name;
    
    /**
     * This method sets price increases and name of ticket types
     * @param name Name of ticket type
     * @param percentageIncreaseInPrice The percentage increase in price
     */
    public TicketTypes(String name, float percentageIncreaseInPrice){
        this.percentageIncreaseInPrice = percentageIncreaseInPrice;
        this.name = name;
    }
    
    /**
     * This method sets price increases and name of ticket types
     * @param name Name of ticket type
     * @param junkVar Bool
     * @param setPrice The set price of the ticket type
     */
    public TicketTypes(String name, Boolean junkVar , float setPrice){
        this.name = name;
        this.setPrice = setPrice;
    }
    
    /**
     * This method gets the price of the ticket type
     * @param price Price of a specific ticket type
     * @return setPrice The set price of a ticket
     * @return price * percentageIncreaseInPrice How much a ticket costs with the increase
     */
    public float getPrice(float price ){
        if (setPrice != -1){
            return setPrice;
        }else {
            return price * percentageIncreaseInPrice;
        }
    }
}
