/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.List;

/**
 *
 * @author Bomie
 */
public class Token {

    /**
     * This method is the constructor for the Token class
     * @param TokenUser An instance of an Account
     * @param type Type of the ticket/token
     */
    public Token(Passenger TokenUser, TicketTypes type) {
        int temp;
        if (!SetOfTokens.listOfTokens.isEmpty()) {
            temp = SetOfTokens.listOfTokens.get(SetOfTokens.listOfTokens.size() - 1).tokenID;
        } else {
            temp = -1;
        }
        tokenID = temp + 1;
        this.TokenUser = TokenUser;
        this.type = type;
        DemoForms.TokenMonitor var = new DemoForms.TokenMonitor();
        new Thread(new DemoForms.TokenUpdater(var)).start();
        var.localToken = this;
    }

    /**
     * This method is another constructor for the Token class
     * @param type Type of the ticket/token
     */
    public Token(TicketTypes type) {
        int temp;
        if (!SetOfTokens.listOfTokens.isEmpty()) {
            temp = SetOfTokens.listOfTokens.get(SetOfTokens.listOfTokens.size() - 1).tokenID;
        } else {
            temp = -1;
        }
        tokenID = temp + 1;
        this.type = type;
        DemoForms.TokenMonitor var = new DemoForms.TokenMonitor();
        new Thread(new DemoForms.TokenUpdater(var)).start();
        var.localToken = this;
    }
    
    public static SmartCard card;

    /**
     * This method returns the SmartCard account
     * @return card smartcard
     */
    public SmartCard getAccount() {
        return card;
    }
    
    private int tokenID;
    public TicketTypes type;
    public Passenger TokenUser;

    /**
     * This method sets the Token's value of discounted to either true or false
     * @param discounted true or false
     */
    public void setDiscounted(boolean discounted) {
        this.discounted = discounted;
    }

    /**
     * This method retrieves the TokenID
     * @return tokenID the ID of the token
     */
    public int getTokenID() {
        return tokenID;
    }

    /**
     * This method retrieves the type of the token/ticket
     * @return type.name The name of the token/ticket type
     */
    public String getTokenType() {
        if (type != null) {
            return type.name;
        }
        return "";
    }

    /**
     * This method returns how many journeys the Token has accounted for
     * @return journeyCounter number of journeys
     */
    public int getJourneyCounter() {
        return journeyCounter;
    }

    /**
     * This method returns whether the Token/ticket price is discounted or not
     * @return discounted bool value true or false
     */
    public boolean isDiscounted() {
        return discounted;
    }

    /**
     * This method returns whether the Token/ticket has been scanned yet
     * @return scanned bool value true or false
     */
    public boolean isScanned() {
        return scanned;
    }

    /**
     * This method sets the Token's value of scanned to either true or false
     * @param scanned true or false
     */
    public void setScanned(boolean scanned) {
        this.scanned = scanned;
    }
    
    private String tokenType;
    private boolean scanned = false;
    private int journeyCounter;
    private boolean discounted;

    /**
     * This method sets the increases the journeyCounter by 1
     */
    public void incrementJourney() {
        journeyCounter += 1;
    }

    /**
     * This method checks if the user has sufficient credit to pay for the journey
     * @return True if the user has sufficient credit
     */
    public boolean hasSufficentCredit() {
        if (TokenUser.type.equals("NormalAccount")) {
            NormalAccount username = (NormalAccount) TokenUser;
            Account tempAccount = username.getUsername();
            return tempAccount.getBalance() > SetOfJourneys.getAmountForAllJourneys(tempAccount.getAccountUserName());
        } else {
            return true;
        }
    }
    
    private List<Journey> listOfJourneys;

    /**
     * This method returns the list of journeys associated with the Token/Ticket
     * @return listOfJourneys The list of journeys
     */
    public List<Journey> getListOfJourneys() {
        return listOfJourneys;
    }

    /**
     * This method sets the list of journeys for the Token/Ticket
     */
    public void setListOfJourneys(List<Journey> list) {
        listOfJourneys = list;
    }
}
