/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

/**
 *
 * @author Bomie
 */


public abstract class Passenger {
    public String type;
    /**
     * This method retrieves the Passenger type
     * @return type Passenger type
     */
    public String getType(){
        return type;
    }
}
