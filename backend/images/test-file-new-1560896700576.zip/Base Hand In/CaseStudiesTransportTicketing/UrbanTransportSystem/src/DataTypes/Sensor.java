/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import urbantransportsystem.GateController;

/**
 *
 * @author BrianSkullMouse
 */
public class Sensor {
    private boolean passengerOnSensor;
    public Token tokenUsed;
    public String location;
    public GateController localGate;
    public Sensor (String location, GateController localGate){
        this.location = location;
        this.localGate = localGate;
        DemoForms.SensorMonitor var = new DemoForms.SensorMonitor();
        var.localSensor = this;
        new Thread(new DemoForms.SensorUpdater(var)).start();
    }
    
    /**
     * This method checks if a passenger is on a sensor
     * @return true if passenger is on sensor, false if not
     */
    public boolean isPassengerOnSensor(){
        if(passengerOnSensor)
        {
            return true;
        }
        return false;
    }
    
    /**
     * This checks to see if user has presented the token to the sensor
     * @param tokenOnSensor Result of isPassengerOnSensor
     */
    public void scanArea(Token tokenOnSensor){
        if (isPassengerOnSensor()){
            tokenUsed = tokenOnSensor;
        }
    }
}
