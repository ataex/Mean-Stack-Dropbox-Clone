/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DataTypes;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Bomie
 */
public class SetOfTokens {
        public static List<Token> listOfTokens = new ArrayList<Token>();
    
    /**
     * This method attempts to find the specified token based on id
     * @param id The token id to search for
     * @return  null if failed, Token if found
     */
    public static Token findToken(int id){
        for(Token t : listOfTokens){
            if (t.getTokenID() == id){
                return t;
            }
        }
        return null;
    }
}
