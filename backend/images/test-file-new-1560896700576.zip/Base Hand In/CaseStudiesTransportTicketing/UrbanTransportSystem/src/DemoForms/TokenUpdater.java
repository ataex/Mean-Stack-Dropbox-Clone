/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DemoForms;

import DataTypes.Journey;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JList;

/**
 *
 * @author Bomie
 */
public class TokenUpdater implements Runnable{
    
    /**
     * This method initialises the TokenUpdater and sets the form to visible
     * @param localForm The local form to show
     */
    public TokenUpdater(TokenMonitor localForm){
        this.localForm = localForm;
        localForm.setVisible(true);
    }
    
    public TokenMonitor localForm;
    
    /**
     * This method checks to see if the token has been discounted or scanned and displays lists of journeys
     */
    @Override
    public void run() {
        do{
            if (localForm.localToken.isDiscounted())
                localForm.discounted.setText("The token is discounted");
            else
                localForm.discounted.setText("The token is not discounted");
            if (localForm.localToken.isScanned())
                localForm.scanned.setText("Has been scanned");
            else
                localForm.scanned.setText("Has not been scanned");
            
            localForm.tokenId.setText(localForm.localToken.getTokenID()+"");
            localForm.tokenType.setText(localForm.localToken.getTokenType());
            if (localForm.localToken.getListOfJourneys() != null){
                List<String> localList = new ArrayList<>();
                for (Journey tempJourney: localForm.localToken.getListOfJourneys()){
                    localList.add(tempJourney.getFromLocation() +" - " + tempJourney.getToLocation());
                }
                localForm.allStops.setListData(localList.toArray(new String[0]));
            }
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SensorUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
        }while (true);
    }
    
}
