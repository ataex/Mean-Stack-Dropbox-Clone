/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DemoForms;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bomie
 */
public class SensorUpdater implements Runnable{
    
    /**
     * This method initialises the SensorUpdater and sets the form to visible
     * @param localForm The local form to show
     */
    public SensorUpdater(SensorMonitor localForm){
        this.localForm = localForm;
        localForm.setVisible(true);
    }
    
    /**
     * This method checks to see if the gate has been lifted and that a token has been scanned or is in use
     */
    public SensorMonitor localForm;
    @Override
    public void run() {
        do{
            if (localForm.localSensor.isPassengerOnSensor())
                localForm.localGateLifted.setText("the gate is lifted");
            else 
                localForm.localGateLifted.setText("The gate is down");
            localForm.location.setText(localForm.localSensor.location);
            if (localForm.localSensor.tokenUsed == null)
                localForm.token.setText("There is no token currently in use");
            else
                localForm.token.setText("The token used had the id of "  + localForm.localSensor.tokenUsed.getTokenID() +"");
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SensorUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
        }while (true);
    }
    
}
