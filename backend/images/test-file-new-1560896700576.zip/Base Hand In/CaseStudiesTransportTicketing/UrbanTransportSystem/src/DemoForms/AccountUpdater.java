/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DemoForms;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Bomie
 */
public class AccountUpdater implements Runnable{
    
    /**
     * This method initialises the AccountUpdater and sets the form to visible
     * @param localForm The local form to show
     */
    public AccountUpdater(AccountMonitor localForm){
        this.localForm = localForm;
        localForm.setVisible(true);
    }
    
    
    private AccountMonitor localForm;
    
    /**
     * This method sets the accountUserName, creditAmount and accountType on the local form
     */
    @Override
    public void run() {
        do{
            localForm.accountUserName.setText(localForm.localAccount.getAccountUserName());
            localForm.creditAmount.setText(localForm.localAccount.getBalance() +"");
            localForm.type.setText(localForm.localAccount.getAccountType());
            try {
                Thread.sleep(10000);
            } catch (InterruptedException ex) {
                Logger.getLogger(SensorUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
        }while (true);
    }
    
}
