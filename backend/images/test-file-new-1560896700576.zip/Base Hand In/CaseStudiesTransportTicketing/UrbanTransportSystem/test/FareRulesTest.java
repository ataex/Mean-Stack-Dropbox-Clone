
import org.junit.Assert;
import org.junit.Test;
import DataTypes.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import DataLayer.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Matt
 */
public class FareRulesTest {
    
   //before method, after method 
    
    /**
     * The following tests are to test methods in the FareRules class.
     */
    @Test 
    public void TestFareRules_Pass(){
        Token t = new Token(new NormalAccount(new Account("Name", "pass", "type", 0.4, "name"), LocalDate.now()), new TicketTypes("Normal", 100f));
        List<String> tempList = Arrays.asList("Test", "test2");
        FareRules rules = new FareRules(tempList, 40.32f, 0.9, 20f);
        
        Assert.assertEquals(40.32f, rules.calculateFare(t), 0);
        t.setDiscounted(true);
        Assert.assertEquals(36.288f, rules.calculateFare(t), 0);
        
        Assert.assertEquals(20.16f,rules.calculateDiscount(0.5), 0);
        
        Assert.assertNotNull(rules.getMinAmount());
        Assert.assertNotNull(rules.getFareRules());
        Assert.assertNotNull(rules.getNumForDayPass());
    }
    
    @Test
    public void TestFareRules_Fail(){
        Token t = new Token(new NormalAccount(new Account("Name", "pass", "type", 0.4, "name"), LocalDate.now()), new TicketTypes("Normal", 100f));
        List<String> tempList = Arrays.asList("Test", "test2");
        FareRules rules = new FareRules(tempList, 84.21f, 0.9, 20f);
        
        Assert.assertNotEquals(40.32f, rules.calculateFare(t), 0);
        t.setDiscounted(true);
        Assert.assertNotEquals(36.288f, rules.calculateFare(t), 0);
        
        Assert.assertNotEquals(20.16f,rules.calculateDiscount(0.5), 0);
    }
}
