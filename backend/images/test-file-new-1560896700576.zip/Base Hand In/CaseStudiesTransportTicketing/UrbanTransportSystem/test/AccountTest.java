
import org.junit.Assert;
import org.junit.Test;
import DataTypes.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import DataLayer.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Matt
 */
public class AccountTest {
   
    /**
     * The following tests are to test methods in the Account class.
     */
    @Test
    public void TestAccount_Pass(){
        Account account = new Account("Name", "Pass", "Type", 40.32, "name");
        Assert.assertEquals("Name", account.getAccountUserName());
        Assert.assertEquals("Pass", account.getAccountPassword());
        Assert.assertEquals("Type", account.getAccountType());
        
        Assert.assertEquals(40.32 , account.getBalance(), 0);
        account.processTopUp(5.00f, PaymentTypes.CASH);
        Assert.assertEquals(45.32, account.getBalance(), 0);
        
        account.updateBalance((float)35.92);
        Assert.assertEquals((float)81.24, (float)account.getBalance(), 0);

        Assert.assertTrue(account.isPasswordValid("Pass"));
    }
    
    @Test
    public void TestAccount_Fail(){
        Account account = new Account("Name", "Pass", "Type", 40.32, "name");
        Assert.assertNotEquals("Barry", account.getAccountUserName());
        Assert.assertNotEquals("123", account.getAccountPassword());
        Assert.assertNotEquals("Anon", account.getAccountType());
        
        Assert.assertNotEquals(60.12 , account.getBalance(), 0);
        account.processTopUp(12.00f, PaymentTypes.CASH);
        Assert.assertNotEquals(4, account.getBalance(), 0);
        
        account.updateBalance((float)0.01);
        Assert.assertNotEquals((float)100, (float)account.getBalance(), 0);
        
        Assert.assertFalse(account.isPasswordValid("1"));
    }
}
