
import org.junit.Assert;
import org.junit.Test;
import DataTypes.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import DataLayer.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Matt
 */
public class ServerTest {
    
   //before method, after method 
   
    /**
     * The following tests are to test methods in the Server class.
     */
    @Test
    public void TestServer_Pass(){
        Assert.assertNotNull(SetOfStaffAccounts.listOfStaffAccounts = MongoDBController.getStaffAccounts());
        Assert.assertNotNull(SetOfAccounts.setOfAccounts = MongoDBController.getAccounts());
        Assert.assertNotNull(SetOfTokens.listOfTokens = MongoDBController.getTokens());
        Assert.assertNotNull(SetOfJourneys.journey = MongoDBController.getJourneys());
        Assert.assertNotNull(SetOfSensors.listOfSensors = MongoDBController.getSensors());
        Assert.assertNotNull(SetOfSmartCard.listOfSmartCards = MongoDBController.getSmartCards());
        Assert.assertNotNull(SetOfRoutes.routes = MongoDBController.getRoutes());
        Assert.assertNotNull(SetOfDiscounts.discountTypes = MongoDBController.getDiscounts());
    }
    
    @Test
    public void TestServer_Fail(){
        List<Journey> tempJourneys = new ArrayList<>();
        List<Routes> tempRoutes = new ArrayList<>();
        List<Discount> tempDiscounts = new ArrayList<>();
        
        Assert.assertNull(SetOfStaffAccounts.listOfStaffAccounts);
        Assert.assertNull(SetOfAccounts.setOfAccounts);
        Assert.assertEquals(tempJourneys, SetOfJourneys.journey);
        Assert.assertEquals(tempJourneys, SetOfJourneys.journey);
        Assert.assertNull(SetOfSensors.listOfSensors);
        Assert.assertNull(SetOfSmartCard.listOfSmartCards);
        Assert.assertEquals(tempRoutes, SetOfRoutes.routes);
        Assert.assertEquals(tempDiscounts, SetOfDiscounts.discountTypes);
    }
}
