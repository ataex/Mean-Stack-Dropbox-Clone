
import org.junit.Assert;
import org.junit.Test;
import DataTypes.*;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import DataLayer.*;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Matt
 */
public class TokenTest {
    
    /**
     * The following tests are to test methods in the Token class.
     */
    @Test 
    public void TestToken_Pass(){
        Token t = new Token(new NormalAccount(new Account("Name", "pass", "type", 0.4, "name"), LocalDate.now()), new TicketTypes("Normal", 100f));
        Assert.assertTrue(t.hasSufficentCredit());
        
        Assert.assertEquals(0, t.getTokenID());
        Assert.assertEquals("Normal", t.getTokenType());
        Assert.assertEquals(0, t.getJourneyCounter());
        
        Assert.assertFalse(t.isDiscounted());
        t.setDiscounted(true);
        Assert.assertTrue(t.isDiscounted());
        
        Assert.assertFalse(t.isScanned());
        t.setScanned(true);
        Assert.assertTrue(t.isScanned());
        
        Assert.assertNull(t.getListOfJourneys());
    }
    
    @Test 
    public void TestToken_Fail(){
        Token t = new Token(new NormalAccount(new Account("Name", "pass", "type", 0.0 , "name"), LocalDate.now()), new TicketTypes("Normal", 100f));
        Assert.assertFalse(t.hasSufficentCredit());
        
        Assert.assertNotEquals(12, t.getTokenID());
        Assert.assertNotEquals("Anon", t.getTokenType());
        Assert.assertNotEquals(3, t.getJourneyCounter());
    }
}
